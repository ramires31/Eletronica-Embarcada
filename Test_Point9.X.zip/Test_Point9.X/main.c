/**
  Generated Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This is the main file generated using PIC10 / PIC12 / PIC16 / PIC18 MCUs

  Description:
    This header file provides implementations for driver APIs for all modules selected in the GUI.
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.81.8
        Device            :  PIC16F1827
        Driver Version    :  2.00
*/

/*
    (c) 2018 Microchip Technology Inc. and its subsidiaries. 
    
    Subject to your compliance with these terms, you may use Microchip software and any 
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party 
    license terms applicable to your use of third party software (including open source software) that 
    may accompany Microchip software.
    
    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER 
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY 
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS 
    FOR A PARTICULAR PURPOSE.
    
    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP 
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO 
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL 
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT 
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS 
    SOFTWARE.
*/

#include "mcc_generated_files/mcc.h"

// --- Comandos poss�veis via UART ---
#define COMANDO_LISTA    'L'
#define COMANDO_AGENDAR  'A'
#define COMANDO_PROXIMO  'P'
#define COMANDO_RESETAR  'R'

// --- Mensagens do sistema ---
const char MSG_MENU[]    = "L-Lista | A-Agenda | P-Proximo | R-Reset";
const char MSG_LISTA[]   = "Lista de agendamentos";
const char MSG_VAZIA[]   = "Lista de agendamentos vazia";
const char MSG_PROX[]    = "Proximo: ";
const char MSG_PEDIR[]   = "Digite o nome:";
const char MSG_INVALIDO[]= "Nome vazio. Nao agendado.";
const char MSG_SUCESSO[] = "Agendamento realizado.";
const char MSG_CHEIA[]   = "Nao disponemos de mais agendamentos";
const char MSG_TODOS[]   = "Todos os agendamentos foram atendidos";

// --- Vari�veis globais ---
uint8_t caractere_recebido;
bool aguardando_comando = false;
char comando_atual;
int total_agendados = 0;
int proximo_indice = 0;

// Buffer de recep��o de nome
union {
    char raw[22];
    struct {
        char nome[22];
    };
} buffer_nome;


/*
                         Main application
 */

// --- Envia texto pela UART ---
void enviarTexto(const char *mensagem) {
    while (*mensagem != '\0') {
        EUSART_Write(*mensagem++);
    }
    EUSART_Write('\r'); // Enter
}

// --- Fun��o de execu��o do comando ---
void executarComando() {
    switch (comando_atual) {
        
        case COMANDO_LISTA:
            if (total_agendados == 0 || DATAEE_ReadByte(0) == '$') {
                enviarTexto(MSG_VAZIA);
                total_agendados = 0;
            } else {
                enviarTexto(MSG_LISTA);
                for (int i = 0; i < total_agendados; i++) {
                    int endereco = i * 22;
                    bool lendo = true;
                    while (lendo) {
                        caractere_recebido = DATAEE_ReadByte(endereco);
                        if (caractere_recebido == '\r') {
                            EUSART_Write('\r');
                            lendo = false;
                        } else if (caractere_recebido == '$') {
                            aguardando_comando = false;
                            break;
                        } else {
                            EUSART_Write(caractere_recebido);
                            endereco++;
                        }
                    }
                }
            }
            aguardando_comando = false;
            break;

        case COMANDO_AGENDAR:
            if (total_agendados < 10) {
                int endereco = total_agendados * 22;
                int pos = 0;
                bool lendo = true;

                DATAEE_WriteByte(endereco++, '\0');
                enviarTexto(MSG_PEDIR);

                while (lendo) {
                    if (EUSART_is_rx_ready()) {
                        caractere_recebido = EUSART_Read();
                        if (caractere_recebido == '\r' || pos == 21) {
                            int backup = pos;

                            while (pos < 21) buffer_nome.nome[pos++] = '\0';
                            buffer_nome.nome[backup] = '\r';

                            pos = backup;

                            if (pos == 0) {
                                buffer_nome.nome[0] = '$';
                                enviarTexto(MSG_INVALIDO);
                                lendo = false;
                            } else {
                                total_agendados++;
                                enviarTexto(MSG_SUCESSO);
                                lendo = false;
                            }
                        } else {
                            buffer_nome.nome[pos++] = caractere_recebido;
                        }
                    }
                }

                // Salva na EEPROM
                for (int j = 0; j < 22; j++) {
                    DATAEE_WriteByte(endereco++, buffer_nome.nome[j]);
                }

            } else {
                enviarTexto(MSG_CHEIA);
            }
            aguardando_comando = false;
            break;

        case COMANDO_PROXIMO:
            if (proximo_indice < total_agendados) {
                enviarTexto(MSG_PROX);
                int endereco = 22 * proximo_indice;

                for (int i = 0; i < 22; i++) {
                    caractere_recebido = DATAEE_ReadByte(endereco);
                    if (caractere_recebido == '\r') {
                        EUSART_Write('\r');
                        break;
                    } else if (caractere_recebido == '$') {
                        aguardando_comando = false;
                        break;
                    } else {
                        EUSART_Write(caractere_recebido);
                        endereco++;
                    }
                }

                // Marca o nome como atendido (X no in�cio)
                endereco = 22 * proximo_indice;
                DATAEE_WriteByte(endereco, 'X');
                proximo_indice++;

            } else if (proximo_indice == 0) {
                enviarTexto(MSG_VAZIA);
            } else {
                enviarTexto(MSG_TODOS);
            }

            aguardando_comando = false;
            break;

        case COMANDO_RESETAR:
            for (int i = 0; i < total_agendados; i++) {
                DATAEE_WriteByte(i * 22, '$');
            }
            total_agendados = 0;
            proximo_indice = 0;
            aguardando_comando = false;
            break;
    }
}

void main(void)
{
    // initialize the device
    SYSTEM_Initialize();
    enviarTexto(MSG_MENU);

    // When using interrupts, you need to set the Global and Peripheral Interrupt Enable bits
    // Use the following macros to:

    // Enable the Global Interrupts
    //INTERRUPT_GlobalInterruptEnable();

    // Enable the Peripheral Interrupts
    //INTERRUPT_PeripheralInterruptEnable();

    // Disable the Global Interrupts
    //INTERRUPT_GlobalInterruptDisable();

    // Disable the Peripheral Interrupts
    //INTERRUPT_PeripheralInterruptDisable();

    while (1)
    {
        if (EUSART_is_rx_ready()) {
            caractere_recebido = EUSART_Read();

            if (aguardando_comando) {
                if (caractere_recebido == '\r') {
                    executarComando();
                } else {
                    aguardando_comando = false;
                    EUSART_Write('\r');
                }

            } else {
                if (caractere_recebido == COMANDO_AGENDAR ||
                    caractere_recebido == COMANDO_LISTA ||
                    caractere_recebido == COMANDO_PROXIMO ||
                    caractere_recebido == COMANDO_RESETAR) {
                    
                    aguardando_comando = true;
                    comando_atual = caractere_recebido;

                } else {
                    enviarTexto(MSG_MENU);
                }
            }
        }// Add your application code
    }
}
/**
 End of File
*/